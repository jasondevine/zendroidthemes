<?php
/**
 *	This is a floating 'Buy' element so that anyone
 *  browsing has the option of a direct link back to Themeforest
 *   from any page that contains this footer
 *
 * @package zendroidPress
 * @since zendroidPress 1.0.0
 */
?>


<a href="https://zendroidthemes.com" title="Purchase now on ThemeForest"><div class="stickybuy"><i class="fas fa-shopping-basket"></i><span>Buy</span></div></a>