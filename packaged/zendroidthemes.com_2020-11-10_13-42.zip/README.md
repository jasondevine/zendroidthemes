# zendroidthemes
Theme for zendroidthemes.com landing page, child theme of Amplifier
