# Changelog

All notable changes to this project will be documented in this file. See [standard-version](https://github.com/conventional-changelog/standard-version) for commit guidelines.

### 1.3.4 (2020-11-12)


### Bug Fixes

* installed standard-version and added in .versionrc to help with that ([bf76042](https://github.com/jasondevine/zendroidpress/commit/bf7604283bed692cb6b42bdb701526be9348175e))

### 1.3.4 (2020-11-12)


